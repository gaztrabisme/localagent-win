"""Run the caller's acceptance command and decide whether the work is done.

`finish_reason == 'completed'` means the child's turn ended cleanly. It does not
mean the task is right, and an agent declaring victory prematurely is a primary
failure mode of long-running harnesses. So the caller states the command that
proves the work, and this module runs it -- the server, not the child. A child
reporting its own test results is a claim; an exit code is a fact.

The command is classified through the same `guard` policy the child's own calls
go through before it executes. The caller is another agent and can be prompt
injected, so "the caller asked for it" is not authorization on its own. Only a
command the classifier positively ALLOWs runs; escalate and deny both block.
"""

from __future__ import annotations

import subprocess
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .config import Settings, log
from .guard.classify import ALLOW, classify_verification

OUTPUT_TAIL_CHARS = 2000


@dataclass
class VerificationResult:
    command: str
    passed: bool
    reason: str
    exit_code: int | None = None
    output: str = ""
    counts: dict[str, int] | None = None
    duration_seconds: float = 0.0

    @property
    def output_tail(self) -> str:
        return self.output[-OUTPUT_TAIL_CHARS:] if len(self.output) > OUTPUT_TAIL_CHARS else self.output

    def as_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {
            "command": self.command,
            "passed": self.passed,
            "reason": self.reason,
            "duration_seconds": round(self.duration_seconds, 1),
        }
        if self.exit_code is not None:
            out["exit_code"] = self.exit_code
        if self.counts is not None:
            out["counts"] = self.counts
        if self.output_tail:
            out["output_tail"] = self.output_tail
        return out


def run_verification(
    command: str, workspace: Path, settings: Settings, budget: float | None = None
) -> VerificationResult:
    """Classify, then execute, then report. Never raises.

    `budget` is the seconds left on the run's own deadline. Without it a slow
    command can still be running when the reaper decides the run is overdue,
    and the reaper's kill does not reach a subprocess this thread is blocked in
    -- so the run would outlive its own agent. The shorter of the two wins.
    """
    timeout = settings.verify_timeout
    if budget is not None:
        timeout = max(1.0, min(timeout, budget))
    command = (command or "").strip()
    if not command:
        return VerificationResult(command, False, "no verification command was given")

    verdict = classify_verification(command, workspace)
    if verdict.action != ALLOW:
        log.warning("verification blocked (%s): %s", verdict.action, verdict.reason)
        return VerificationResult(
            command, False, f"blocked before execution: {verdict.reason}"
        )

    if command == "true":
        # The no-op acceptance (`subagent doctor --prompt` sends it). Answered
        # here rather than by a shell: Windows has no `true` binary.
        return VerificationResult(command, True, "exit 0", 0, "", None, 0.0)

    started = time.time()
    try:
        # Executed through a shell because an acceptance command is written as a
        # shell line; every segment of it was classified above.
        completed = subprocess.run(  # noqa: S602 - shell use is the classified path
            command,
            shell=True,
            cwd=str(workspace),
            capture_output=True,
            text=True,
            timeout=timeout,
        )
    except subprocess.TimeoutExpired:
        limit = (
            f"[core].verify_timeout ({settings.verify_timeout:g}s)"
            if timeout >= settings.verify_timeout
            else f"the run's remaining deadline ({timeout:g}s)"
        )
        return VerificationResult(
            command,
            False,
            f"timed out after {limit}",
            duration_seconds=time.time() - started,
        )
    except OSError as exc:
        return VerificationResult(
            command,
            False,
            f"could not run: {type(exc).__name__}: {exc}",
            duration_seconds=time.time() - started,
        )

    duration = time.time() - started
    output = ((completed.stdout or "") + (completed.stderr or "")).strip()
    from .loop.detect import parse_test_counts

    counts = parse_test_counts(output)
    if completed.returncode == 0:
        return VerificationResult(
            command, True, "exit 0", 0, output, counts, duration
        )
    return VerificationResult(
        command,
        False,
        f"exited {completed.returncode}",
        completed.returncode,
        output,
        counts,
        duration,
    )
