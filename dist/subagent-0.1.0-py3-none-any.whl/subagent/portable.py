"""The four places the package touches an OS-specific API, behind one name each.

POSIX behaviour is what it was before Windows was a target: an flock on the
lane-state lock file, `start_new_session=True` on every child, and
`os.killpg` to take a child's whole process group down. On Windows the same
calls become `msvcrt.locking`, `CREATE_NEW_PROCESS_GROUP`, and
`taskkill /T` (the process tree) with `terminate()` as the fallback.
"""

from __future__ import annotations

import contextlib
import os
import subprocess
import sys
from typing import IO, Any

IS_WINDOWS = sys.platform == "win32"

if IS_WINDOWS:  # pragma: no cover - exercised on the Windows VM
    import msvcrt
else:
    import fcntl
    import signal


def lock_file(handle: IO[Any]) -> None:
    """Take an exclusive lock on an open file; blocks until it is free.

    On Windows `msvcrt.locking` locks a byte range from the current offset, so
    the offset is pinned to 0 first (the lock file is never written to).
    """
    if IS_WINDOWS:  # pragma: no cover
        handle.seek(0)
        msvcrt.locking(handle.fileno(), msvcrt.LK_LOCK, 1)
    else:
        fcntl.flock(handle, fcntl.LOCK_EX)


def unlock_file(handle: IO[Any]) -> None:
    """Release `lock_file`'s lock. Closing the handle releases it too on POSIX."""
    if IS_WINDOWS:  # pragma: no cover
        handle.seek(0)
        with contextlib.suppress(OSError):
            msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
    else:
        fcntl.flock(handle, fcntl.LOCK_UN)


def group_kwargs() -> dict[str, Any]:
    """Popen keyword arguments that put the child in its own group, so
    `kill_tree` can take it and everything it spawned down together."""
    if IS_WINDOWS:  # pragma: no cover
        return {"creationflags": subprocess.CREATE_NEW_PROCESS_GROUP}
    return {"start_new_session": True}


def kill_tree(proc: subprocess.Popen[Any], grace: float = 5.0) -> None:
    """Stop `proc` and its descendants: a polite request first, then force
    after `grace` seconds. Returns once the process is gone (or after the
    forced kill was issued when even that cannot be waited on)."""
    if proc.poll() is not None:
        return
    if IS_WINDOWS:  # pragma: no cover
        # There is no SIGTERM to a tree; terminate() stops only the direct
        # child. taskkill /T walks the tree, so it goes first.
        _taskkill(proc.pid, force=False)
        proc.terminate()
        try:
            proc.wait(timeout=grace)
        except subprocess.TimeoutExpired:
            _taskkill(proc.pid, force=True)
            proc.kill()
            _wait_quietly(proc, grace)
        return
    try:
        os.killpg(proc.pid, signal.SIGTERM)
    except (ProcessLookupError, PermissionError, OSError):
        proc.terminate()
    try:
        proc.wait(timeout=grace)
    except subprocess.TimeoutExpired:
        try:
            os.killpg(proc.pid, signal.SIGKILL)
        except (ProcessLookupError, PermissionError, OSError):
            proc.kill()
        _wait_quietly(proc, grace)


def _wait_quietly(proc: subprocess.Popen[Any], grace: float) -> None:
    with contextlib.suppress(subprocess.TimeoutExpired):
        proc.wait(timeout=grace)


def _taskkill(pid: int, *, force: bool) -> None:  # pragma: no cover - Windows only
    argv = ["taskkill", "/T", "/PID", str(pid)]
    if force:
        argv.insert(1, "/F")
    with contextlib.suppress(OSError, subprocess.SubprocessError):
        subprocess.run(argv, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                       stderr=subprocess.DEVNULL, timeout=15, check=False)


__all__ = ["IS_WINDOWS", "group_kwargs", "kill_tree", "lock_file", "unlock_file"]
